﻿namespace GoMartApp
{


    partial class BillDataset
    {
        partial class BillDatasetDataTable
        {
        }
    }
}
