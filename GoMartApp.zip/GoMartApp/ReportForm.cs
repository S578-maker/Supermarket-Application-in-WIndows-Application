﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;

namespace GoMartApp
{
    public partial class ReportForm: Form
    {
        public DataTable _dataTable;
        public DataSet dsReport;
        public BillDataset billDataset = new BillDataset();
        public DataTable table =new DataTable();

        public ReportForm(DataTable dtPrint)
        {
            InitializeComponent();
            dsReport = new DataSet();
            _dataTable = new DataTable();
            _dataTable = dtPrint;
          
            dsReport.Tables.Add(_dataTable);
            //-------------------
            DataTable table = new DataTable("DataTable1");

            // Add columns to match the XSD definition
            table.Columns.Add("Bill_ID", typeof(int));
            table.Columns.Add("SellerID", typeof(string));
            table.Columns.Add("SellDate", typeof(DateTime));
            table.Columns.Add("TotalAmt", typeof(decimal));

            billDataset.Tables.Add(table);
            //----------------



            //table = billDataset.Tables["DataTable1"];
           

            table = _dataTable;
            LoadReport(table);
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
             billDataset = new BillDataset();

          
            //this.reportViewer1.RefreshReport();
            //this.reportViewer2.RefreshReport();
        }
        private void LoadReport(DataTable dt)
        {

            // Open the report form and pass the DataTable



            string reportPath = System.IO.Path.Combine(Application.StartupPath, @"D:\dot net\Trial\Windows\GoMartApp\GoMartApp\BillReport.rdlc");
            
            reportViewer1.LocalReport.ReportPath = reportPath;

            //  ReportDataSource dataSource = new ReportDataSource("BillDataSet", _dataTable);
            ReportDataSource dataSource = new ReportDataSource("BillDataset", dt);
            //  MessageBox.Show($"Rows in DataTable: {_dataTable.Rows.Count}");

            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(dataSource);

            // Refresh and show the report
            reportViewer1.RefreshReport();
            
        }
    }
}
